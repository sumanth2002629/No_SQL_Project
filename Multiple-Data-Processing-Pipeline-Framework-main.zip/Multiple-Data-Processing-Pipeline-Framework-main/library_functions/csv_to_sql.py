import sqlite3
import csv
import sys

# Open the CSV file and read its contents
def csv_to_sql(inputFilename, outputTableName):
    with open(inputFilename, 'r') as file:
        reader = csv.reader(file)
        headers = next(reader) # Assumes the first row contains headers
        rows = [row for row in reader]

    # Create a new SQLite database and a cursor object
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()

    # Create a new table in the database
    table_name = outputTableName
    columns = ', '.join(headers)
    placeholders = ', '.join(['?' for _ in range(len(headers))])
    create_table_sql = f'CREATE TABLE {table_name} ({columns})'
    cursor.execute(create_table_sql)

    # Insert the data into the table
    insert_row_sql = f'INSERT INTO {table_name} VALUES ({placeholders})'
    cursor.executemany(insert_row_sql, rows)

    # Commit the changes and close the connection
    conn.commit()
    conn.close()



if __name__ == "__main__":
    csv_to_sql(sys.argv[1], sys.argv[2])