import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class dropna {
    public static void dropNaNValues(String filePath) throws IOException {
        // Create a File object for the CSV file
        File inputFile = new File(filePath);

        // Create a CSVReader object for reading the CSV file
        CSVReader reader = new CSVReader(new FileReader(inputFile));

        // Create a FileWriter object for writing the output CSV file
        FileWriter outputFile = new FileWriter("output.csv");

        // Create a CSVWriter object for writing to the output CSV file
        CSVWriter writer = new CSVWriter(outputFile);

        // Loop through each row in the CSV file
        String[] nextLine;
        while ((nextLine = reader.readNext()) != null) {
            boolean hasNaN = false;

            // Loop through each element in the current row
            for (String element : nextLine) {
                // Check if the element is NaN
                if (element.equals("NaN")) {
                    hasNaN = true;
                    break;
                }
            }

            // Write the row to the output CSV file if it does not have NaN values
            if (!hasNaN) {
                writer.writeNext(nextLine);
            }
        }

        // Close the input and output files
        reader.close();
        writer.close();
    }
}
