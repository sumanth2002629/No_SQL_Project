import pandas as pd
import sys 
import json 

def slice_dataframe(input, output, column_name, dict):
    '''
    Slices a DataFrame based on conditions on column values.

    Args:
        df (pandas.DataFrame): The DataFrame to slice.
        column_name (str): The name of the column to use for slicing.
        lower_bound: The lower bound for the column values to include in the slice.
        upper_bound: The upper bound for the column values to include in the slice.

    Returns:
        pandas.DataFrame: A DataFrame representing the sliced rows of the input DataFrame.
    '''
    # Create a boolean mask for the rows that meet the conditions
    df = pd.read_csv(input)
    mask = (df[column_name] >= dict["lower_bound"]) & (df[column_name] <= dict["upper_bound"])

    # Apply the mask to the DataFrame to get the sliced DataFrame
    sliced_df = df.loc[mask]
    sliced_df.to_csv(output)

    # Return the sliced DataFrame
    return sliced_df


if __name__ == "__main__":
    args_dict = json.loads(sys.argv[1])
    slice_dataframe(args_dict["input"], args_dict["output"], args_dict["cols"][0]["col"], args_dict["cols"][0])