import pandas as pd 
import sys
import json

def sort_csv(inputFilename, outputFilename, column_name):
    '''
    Sorts data in a CSV file by a particular column.

    Args:
        file_path (str): The path to the CSV file.
        column_name (str): The name of the column to sort by.

    Returns:
        pandas.DataFrame: A DataFrame representing the sorted rows of the CSV file.
    '''
    # Load the CSV file into a DataFrame
    df = pd.read_csv(inputFilename)

    # Sort the DataFrame by the specified column
    sorted_df = df.sort_values(by=column_name)
    sorted_df.to_csv(outputFilename)


    # Return the sorted DataFrame
    return sorted_df



if __name__ == "__main__":
    args_dict = json.loads(sys.argv[1])
    sort_csv(args_dict["input"], args_dict["output"], args_dict["cols"][0]["col"])