import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class csv_to_sql {
    public static void convertCsvToSql(String csvFilePath, String tableName, String sqlFilePath) throws IOException {
        // Create a FileReader object for reading the CSV file
        FileReader inputFile = new FileReader(csvFilePath);

        // Create a BufferedReader object for reading the input file
        BufferedReader bufferedReader = new BufferedReader(inputFile);

        // Create a FileWriter object for writing the SQL file
        FileWriter outputFile = new FileWriter(sqlFilePath);

        // Write the SQL command to create the table
        outputFile.write("CREATE TABLE " + tableName + " (\n");

        // Read the first line of the CSV file to get the column names
        String line = bufferedReader.readLine();
        String[] columnNames = line.split(",");

        // Write the SQL command to create the columns
        for (int i = 0; i < columnNames.length; i++) {
            outputFile.write(columnNames[i] + " VARCHAR(255)");
            if (i < columnNames.length - 1) {
                outputFile.write(",\n");
            }
        }

        // Write the SQL command to close the table creation
        outputFile.write("\n);\n\n");

        // Write the SQL commands to insert the data
        while ((line = bufferedReader.readLine()) != null) {
            String[] values = line.split(",");
            outputFile.write("INSERT INTO " + tableName + " VALUES (");

            for (int i = 0; i < values.length; i++) {
                outputFile.write("'" + values[i] + "'");
                if (i < values.length - 1) {
                    outputFile.write(",");
                }
            }

            outputFile.write(");\n");
        }

        // Close the input and output files
        bufferedReader.close();
        outputFile.close();
    }
}