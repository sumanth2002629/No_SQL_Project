import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Comparator;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class CsvUtil {
    public static void sortCsvByColumn(String filePath, String columnName) throws IOException {
        // Create a File object for the input CSV file
        File inputFile = new File(filePath);

        // Create a CSVReader object for reading the input file
        CSVReader reader = new CSVReader(new FileReader(inputFile));

        // Create a FileWriter object for writing the output CSV file
        FileWriter outputFile = new FileWriter("output.csv");

        // Create a CSVWriter object for writing to the output CSV file
        CSVWriter writer = new CSVWriter(outputFile);

        // Read the first row to get the column headers
        String[] headers = reader.readNext();

        // Find the index of the column to sort by
        int columnIndex = -1;
        for (int i = 0; i < headers.length; i++) {
            if (headers[i].equals(columnName)) {
                columnIndex = i;
                break;
            }
        }

        // Sort the rows based on the specified column
        reader.readAll().sort(Comparator.comparing(o -> o[columnIndex]));

        // Write the column headers to the output CSV file
        writer.writeNext(headers);

        // Write the sorted rows to the output CSV file
        for (String[] row : reader.readAll()) {
            writer.writeNext(row);
        }

        // Close the input and output files
        reader.close();
        writer.close();
    }
}