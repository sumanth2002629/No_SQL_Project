import PyPDF2
import sys 

def read_pdf(inputFileName, outputFileName):
    '''
    Reads text from a PDF document.

    Args:
        file_path (str): The path to the PDF file.

    Returns:
        str: The text extracted from the PDF document.
    '''
    with open(inputFileName, 'rb') as file:
        # Create a PDF reader object
        reader = PyPDF2.PdfReader(file)

        # Get the number of pages in the PDF document
        num_pages = len(reader.pages)

        # Initialize an empty string to hold the text
        text = ''

        # Loop through each page in the PDF document
        for page in range(num_pages):
            # Get the page object for the current page
            page_obj = reader.pages[page]

            # Extract the text from the page
            page_text = page_obj.extract_text()

            # Append the page text to the overall text
            text += page_text

        # Return the extracted text
        with open(outputFileName, "w") as text_file:
            text_file.write("{}".format(text))
    

if __name__ == "__main__":
    read_pdf(sys.argv[1], sys.argv[2])