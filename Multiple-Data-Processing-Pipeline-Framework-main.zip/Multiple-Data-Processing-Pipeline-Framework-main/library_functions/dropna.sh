#!/bin/bash

# Input arguments
input_file="$1"
output_file="$2"

# Get column index
column_index=3

# Drop rows with missing values in the specified column
awk -v col=$column_index -F, 'NR==1 || $col != ""' $input_file > $output_file