import numpy as np
import pandas as pd
import sys
import json 
from ast import literal_eval

def dropna(inputFilename, outputFilename):
    df = pd.read_csv(inputFilename)
    df.dropna()

    if outputFilename:
        df.to_csv(outputFilename)

    return df


if __name__ == "__main__":
    # print(sys.argv[1])
    args_dict = json.loads(sys.argv[1])
    dropna(args_dict["input"], args_dict["output"])