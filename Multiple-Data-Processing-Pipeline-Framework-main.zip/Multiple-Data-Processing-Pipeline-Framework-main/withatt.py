import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

# Set up the email message
msg = MIMEMultipart()
msg['From'] = 'dwork3035@gmail.com'
msg['To'] = 'dajivrajani@gmail.com'
msg['Subject'] = 'Test Email with Attachment'

body = 'This is a test email sent using Python and SMTP with an attachment!'
msg.attach(MIMEText(body, 'plain'))

# Add attachment to the email message
filename = '/home/darshak/Desktop/Academics/6th Sem/Timepass/18-04-2023/A.cpp'
attachment = open(filename, 'rb')
part = MIMEBase('application', 'octet-stream')
part.set_payload(attachment.read())
encoders.encode_base64(part)
part.add_header('Content-Disposition', f'attachment; filename={filename}')
msg.attach(part)

# Set up the SMTP server
smtp_server = 'smtp.gmail.com'
smtp_port = 587
smtp_user = 'dwork3035@gmail.com'
smtp_password = 'zjdydsdiokmkgteb'

server = smtplib.SMTP(smtp_server, smtp_port)
server.ehlo()
server.starttls()
server.ehlo()
server.login(smtp_user, smtp_password)

# Send the email using SMTP
text = msg.as_string()
server.sendmail(smtp_user, 'dajivrajani@gmail.com', text)

# Close the connection
server.quit()