# importing the required packages
import os
import json 
import xml.etree.ElementTree as ET

import threading


# importing the packages for email 
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders




"""
This XML parser takes in an XML file and constructs a tree data structure
that represents the elements and attributes of the XML file. It can then
process all the tasks specified in the XML according to their specified order
and parameters.
"""
class XMLParser:
    def __init__(self, xmlFile):
        """
        object takes in the required XML file and creates an XML tree for parsing
        """
        self.xmlFile = xmlFile
        self.tree = ET.parse(self.xmlFile)
        self.index_count = 0
        self.colkey = None 
        self.filterDict = {}
        self.root = self.tree.getroot()

        self.processes = []      # list of all process tasks
        self.default_input_file = ""   # contains the default input file name
        self.flow_map = {}       # contains the flow map for parallel processing.



    def sendMail(self, child, mailProcess):
        """
        method to send mail
        takes in the element and mailProcess as parameters
        attaches the files, assigns all required elements and sends it using an smtp server 
        """
        msg = MIMEMultipart()
        msg['From'] = 'dwork3035@gmail.com'
        msg['To'] = child.text
        msg['Subject'] = 'From Data Processing Framework'

        body = self.processes[-1]["body"]
        msg.attach(MIMEText(body, 'plain'))

        # Add attachment to the email message
        filename = mailProcess["input"]
        attachment = open(filename, 'rb')
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename={filename}')
        msg.attach(part)

        # Set up the SMTP server
        smtp_server = 'smtp.gmail.com'
        smtp_port = 587
        smtp_user = 'dwork3035@gmail.com'
        smtp_password = 'zjdydsdiokmkgteb'

        server = smtplib.SMTP(smtp_server, smtp_port)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(smtp_user, smtp_password)

        # Send the email using SMTP
        text = msg.as_string()
        server.sendmail(smtp_user, msg['To'], text)

        # Close the connection
        server.quit()






    def parseXML(self):
        """
        parse XML method which given an XML file, parses it and gets all the processes
        """

        for item in self.root.findall(".//"):
            # iterate child elements of item

            # check for default input to set the default input filename
            if item.tag == "default_input":
                default_input_file = item.text


            # checks for the process tag and iterates over the child elements of process
            if item.tag == "process":
                for child in item:
                    

                    # if tag is input sets the input stream of the process
                    # creates a new process object and appends it to the list of processes
                    if child.tag == "input":
                        process = {}
                        process["input"] = child.text
                        if process["input"] is None:
                            process["input"] = default_input_file
                        process["index"] = self.index_count
                        self.index_count += 1
                        self.processes.append(process)

                    # if tag is task, sets the task function of the process
                    # also gets the type of the task, i.e, python, java, etc
                    # and sets the same in the process element
                    elif child.tag == "task":
                        self.processes[-1]["task"] = child.text
                        self.processes[-1]["task_type"] = child.get("type")


                    # if tag is output, sets the output stream of the process
                    elif child.tag == "output":
                        if child.text is not None:
                            self.processes[-1]["output"] = child.text
                        else:
                            self.processes[-1]["output"] = self.processes[-1]["input"]

                    
                    # if tag is conditions iterate over all its child tags
                    # set the colname, condition key-value pairs in the process
                    elif child.tag == "conditions":
                        for condition in child:

                            # if tag is col, set the colname to dictionary
                            if condition.tag == "col": 
                                if child.text is not None:
                                    self.colkey = condition.text 

                            # if tag is condition, create corresponding key, value pairs        
                            elif condition.tag == "condition":
                                key = None 
                                for vals in condition:
                                    if vals.tag == "key":
                                        key = vals.text 
                                    if vals.tag == "value":
                                        self.filterDict[key] = int(vals.text) 


                        # append the key-value condition dictionaries to a list
                        self.filterDict["col"] = self.colkey
                        if "cols" not in self.processes[-1].keys():
                            self.processes[-1]["cols"] = []
                            self.processes[-1]["cols"].append(self.filterDict)
                        
                        else:
                            self.processes[-1]["cols"].append(self.filterDict)

                        self.colkey = None 
                        self.filterDict = {}
                                    
                                

                    # if tag is sequenceId, set the same and
                    # add it to the corresponding key of the flow map
                    elif child.tag == "sequenceId":
                        self.processes[-1]["sequenceId"] = int(child.text)
                        if int(child.text) not in self.flow_map:
                            self.flow_map[int(child.text)] = []
                        self.flow_map[int(child.text)].append(self.processes[-1]["index"])
                    

                    # if tag is body, set the email body
                    elif child.tag == "body":
                        if child.text is not None:
                            self.processes[-1]["body"] = child.text
                        else:
                            self.processes[-1]["body"] = "System generated by data processing framework"
            

                    # if tag is mailto, the system creates a smtp server and sends the mail
                    elif child.tag == "mailto":
                        self.sendMail(child, self.processes[-1])

        self.parseProcesses()


    
    def executeProcess(self, process):
        """
        takes in a process, creates a corresponding script
        gives in the required command line arguments and executes the same
        using os.system() provided by the inbuilt os command
        """
        
        print(process)

        # if python executable then run the above script
        if process["task_type"] == "python":
            jsondump = json.dumps(process)
            script = ["python3", process["task"], '\'%s\'' % str(jsondump)]
            script = " ".join(script)
            os.system(script)

        elif process["task_type"] == "bash":
            jsondump = json.dumps(process)
            script = [process["task"], " ", process["input"], " ", process["output"]]
            script = "".join(script)
            os.system(script)
        
        # if c executable then run the below script
        # run gcc executable - create a.out
        # execute the a.out
        elif process["task_type"] == "c":
            os.system(
                "gcc {} {} {} {}".format(
                    process["task"],
                    process["input"],
                    process["output"]
                    if process["output"] is not None
                    else process["input"],
                    process["col"]
                )
            )
            os.system("./a.out")
        
        
        # if executable is cpp form, run using g++
        # obtain the a.out executable, and run the same
        elif process["task_type"] == "cpp":
            os.system(
                "g++ {} {} {} {}".format(
                    process["task"],
                    process["input"],
                    process["output"]
                    if process["output"] is not None
                    else process["input"],
                    process["col"]
                )
            )
            os.system("./a.out")
        
        
        # if executable is java, compile using javac
        # run the created executable file using java
        elif process["task_type"] == "java":
            os.system(
                "javac {} {} {} {}".format(
                    process["task"],
                    process["input"],
                    process["output"]
                    if process["output"] is not None
                    else process["input"],
                    process["col"]
                )
            )
            os.system("java {}".format(process["task"][:-4]))




    def parseProcesses(self):
        """
        method to parse processes - sequentially and parallely
        if same sequence Id - then execute it parallely, create threads and execute the processes
        else execute the processes in a sequential manner
        """
        for seqId in range(1, len(self.flow_map) + 1):
            if len(self.flow_map[seqId]) == 1:
                self.executeProcess(process=self.processes[self.flow_map[seqId][0]])

            else:
                threadList = []
                for idx in range(0, len(self.flow_map[seqId])):
                    t = threading.Thread(
                        target=self.executeProcess, args=(self.processes[self.flow_map[seqId][idx]],)
                    )
                    threadList.append(t)
                for t in threadList:
                    t.start()
                for t in threadList:
                    t.join()




if __name__ == "__main__":
    xmlParser = XMLParser("./process.xml")
    xmlParser.parseXML()
